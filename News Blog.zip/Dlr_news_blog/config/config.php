<?php
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "dlr_new_blog");
define("TITLE", "welcome to my new website");
define("KEYWORDS", "PHP Tutorials, JAVA Tutorials, Oracle Database, C# Tutorials");

